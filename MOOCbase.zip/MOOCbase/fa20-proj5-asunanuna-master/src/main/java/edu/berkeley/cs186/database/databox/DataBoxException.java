package edu.berkeley.cs186.database.databox;

@SuppressWarnings("serial")
public class DataBoxException extends RuntimeException {
    public DataBoxException(String message) {
        super(message);
    }
}
