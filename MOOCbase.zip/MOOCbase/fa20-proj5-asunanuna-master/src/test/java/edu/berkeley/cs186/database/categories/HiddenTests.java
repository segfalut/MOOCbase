package edu.berkeley.cs186.database.categories;

public interface HiddenTests { /* category marker */ }
