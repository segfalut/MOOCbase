package edu.berkeley.cs186.database.categories;

public interface Proj4Part1Tests extends ProjTests  { /* category marker */ }